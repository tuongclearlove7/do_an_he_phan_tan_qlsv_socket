package org.example.server.service.handle;

public @interface Transactional {
}
