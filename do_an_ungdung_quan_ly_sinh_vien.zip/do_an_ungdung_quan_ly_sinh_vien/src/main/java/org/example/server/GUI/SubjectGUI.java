package org.example.server.GUI;

public class SubjectGUI {

    //GUI (Graphic user interface)

}
